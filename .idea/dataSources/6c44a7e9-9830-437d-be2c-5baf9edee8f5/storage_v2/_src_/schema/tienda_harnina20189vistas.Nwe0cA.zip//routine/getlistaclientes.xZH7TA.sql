create procedure getListaClientes()
  BEGIN
select cliente.* from cliente;
END;

