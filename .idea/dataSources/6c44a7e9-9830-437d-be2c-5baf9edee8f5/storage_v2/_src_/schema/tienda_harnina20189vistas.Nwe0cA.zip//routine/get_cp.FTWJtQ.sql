create procedure get_cp()
  BEGIN
SELECT CodigoPostal FROM codigo_postal;
END;

