create trigger codigopostal_BI_trigger
  before INSERT
  on codigopostal
  for each row
  BEGIN

DECLARE codProvincia varchar(2) DEFAULT "";

IF length(NEW.CodigoPostal) = 5 THEN
      
      IF esNumero2(NEW.CodigoPostal) = 1 THEN 
       
         SET codProvincia = LEFT(NEW.CodigoPostal,2);
         IF (SELECT `CodigoProvincia` FROM `provincia` WHERE `CodigoProvincia`= codProvincia) is null 
            THEN SIGNAL SQLSTATE "45000" SET message_text = "Error Codigo de Provincia No existe";
         END IF;      
      
         ELSE SIGNAL SQLSTATE "45000" SET message_text = "Digitos erroneos No son todos números";
	   END IF;
    ELSE SIGNAL SQLSTATE "45000" SET message_text = "Longitud erronea distinta de 5";
    
END IF;

END;

